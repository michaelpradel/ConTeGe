package instrumentClasses;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

public class InstrumentMethods  {

	public static AtomicInteger instrumentGlobalTS = new AtomicInteger(0);
	public static boolean doInstrumentLog = false;

	public static void instrWriteTofile(String message) {
		String directoryName = "Instrument_Traces";
		String fileName = directoryName + File.separator + "Instrument" + Thread.currentThread().getId();
		try {
			File dir = new File(directoryName);
			if (!dir.exists()) {
				dir.mkdir();
			}File file = new File(fileName);
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(message + "\n");
			bw.close();
		} catch (IOException e) {
				e.printStackTrace();
		}
	}

	public static void instrStartMethod(Object currentObject, String methodExecuted) {
		String message="Start method@" + System.identityHashCode(currentObject) + "@" + methodExecuted + "@" + "@" + instrumentGlobalTS.incrementAndGet();
		instrWriteTofile(message);
	}

	public static void instrEndMethod(Object currentObject, String methodExecuted) {
		String message="End method@" + System.identityHashCode(currentObject) + "@" + methodExecuted + "@" + "@" + instrumentGlobalTS.incrementAndGet();
		instrWriteTofile(message);
	}

	public static void instrEndWithExceptionMethod(Object currentObject, String methodExecuted, String exceptionCaught) {
		String message="End method with exception@" + System.identityHashCode(currentObject) + "@" + methodExecuted + "@" + exceptionCaught + "@" + instrumentGlobalTS.incrementAndGet();
		instrWriteTofile(message);
	}

}