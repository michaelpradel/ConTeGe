package java16.util;

import java.util.Hashtable;

import java16.util.Collections;


public class Factory {
	public static Collections.SynchronizedMap createSyncMap() {
		return (Collections.SynchronizedMap) Collections.synchronizedMap(new Hashtable());
	}
}
